# Cancer Epidemiology Research To Lancet
# 肿瘤学全球数据到柳叶刀

Project ID: demo_20260427_221821
Export Date: 2026-04-27 22:18:48

## Contents

## Papers
- demo_20260427_221821_paper.docx
- demo_20260427_221821_paper.md
- demo_20260427_221821_paper.html

## Charts
- demo_20260427_221821_risk_pie.png
- demo_20260427_221821_trend.png
- demo_20260427_221821_paf.png

## Citation

If you use this data in your research, please cite:
Cancer Epidemiology Research To Lancet Platform
